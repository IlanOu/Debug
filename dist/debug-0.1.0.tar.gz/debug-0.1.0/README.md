# Debugger

Simple debugger Python pour afficher du texte dans la console.
